<!DOCTYPE html>
<html lang="en-US">

<!-- Mirrored from glanz.starkethemes.com/wedding-planner/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 03 Jan 2023 06:01:35 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.0.3/css/font-awesome.css">
<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.no-icons.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" rel="stylesheet" />
<link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.min.css" rel="stylesheet">
<link rel="profile" href="http://gmpg.org/xfn/11">
 
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<!-- Latest compiled and minified CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

<title>A To Infinity Events</title>
<link rel='dns-prefetch' href='http://fonts.googleapis.com/' />
<link rel="stylesheet" href="./about.css">
<link rel='dns-prefetch' href='http://s.w.org/' />
<link rel="alternate" type="application/rss+xml" title="Glanz &raquo; Feed" href="feed/index.html" />
<link rel="alternate" type="application/rss+xml" title="Glanz &raquo; Comments Feed" href="comments/feed/index.html" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/glanz.starkethemes.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.0.18"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])?!1:!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55358,56760,9792,65039],[55358,56760,8203,9792,65039])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='wp-block-library-css'  href='wp-includes/css/dist/block-library/style.min218e.css?ver=5.0.18' type='text/css' media='all' />
<link rel='stylesheet' id='glanztheme-studio-fonts-css'  href='http://fonts.googleapis.com/css?family=Dosis%3A400%2C700%7COpen%2BSans%3A400%2C400i%2C700%2C700i%7CPlayfair+Display%3A400%2C400i%2C700%2C700i&amp;ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='glanztheme-library-css'  href='wp-content/themes/glanztheme/css/glanztheme_library218e.css?ver=5.0.18' type='text/css' media='all' />
<link rel='stylesheet' id='themify-icons-css'  href='wp-content/themes/glanztheme/fonts/themify-icons218e.css?ver=5.0.18' type='text/css' media='all' />
<link rel='stylesheet' id='marsha-font-css'  href='wp-content/themes/glanztheme/fonts/marsha/stylesheet218e.css?ver=5.0.18' type='text/css' media='all' />
<link rel='stylesheet' id='fontawesome-icons-css'  href='wp-content/themes/glanztheme/fonts/font-awesome/css/font-awesome.min218e.css?ver=5.0.18' type='text/css' media='all' />
<link rel='stylesheet' id='glanztheme-main-styles-css'  href='wp-content/themes/glanztheme/css/glanztheme_style218e.css?ver=5.0.18' type='text/css' media='all' />
<link rel='stylesheet' id='glanztheme-style-css'  href='wp-content/themes/glanztheme/style218e.css?ver=5.0.18' type='text/css' media='all' />
<!-- about -->
<link rel='stylesheet' id='glanztheme-style-css'  href='wp-content/themes/glanztheme/css/about.css' type='text/css' media='all' />
<!-- about -->
<link rel='stylesheet' id='fw-ext-breadcrumbs-add-css-css'  href='wp-content/plugins/unyson/framework/extensions/breadcrumbs/static/css/style218e.css?ver=5.0.18' type='text/css' media='all' />
<link rel='stylesheet' id='fw-ext-builder-frontend-grid-css'  href='wp-content/plugins/unyson/framework/extensions/builder/static/css/frontend-gridd115.css?ver=1.2.12' type='text/css' media='all' />
<link rel='stylesheet' id='fw-ext-forms-default-styles-css'  href='wp-content/plugins/unyson/framework/extensions/forms/static/css/frontendda48.css?ver=2.7.24' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='wp-content/plugins/unyson/framework/static/libs/font-awesome/css/font-awesome.minda48.css?ver=2.7.24' type='text/css' media='all' />
<link rel='stylesheet' id='fw-shortcode-section-background-video-css'  href='wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/css/background218e.css?ver=5.0.18' type='text/css' media='all' />
<link rel='stylesheet' id='fw-shortcode-section-css'  href='wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/css/styles218e.css?ver=5.0.18' type='text/css' media='all' />
<link rel='stylesheet' id='fw-shortcode-divider-css'  href='wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/divider/static/css/styles218e.css?ver=5.0.18' type='text/css' media='all' />
<script type='text/javascript' src='wp-includes/js/jquery/jqueryb8ff.js?ver=1.12.4'></script>
<script type='text/javascript' src='wp-includes/js/jquery/jquery-migrate.min330a.js?ver=1.4.1'></script>
<link rel='https://api.w.org/' href='wp-json/index.html' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="xmlrpc0db0.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.0.18" />
<link rel="canonical" href="index.html" />
<link rel='shortlink' href='index03bd.html?p=256' />
<link rel="alternate" type="application/json+oembed" href="wp-json/oembed/1.0/embed4416.json?url=http%3A%2F%2Fglanz.starkethemes.com%2Fwedding-planner%2F" />
<link rel="alternate" type="text/xml+oembed" href="wp-json/oembed/1.0/embed778d?url=http%3A%2F%2Fglanz.starkethemes.com%2Fwedding-planner%2F&amp;format=xml" />
<style type="text/css">.rsvpArea, .rsvpParagraph, #rsvpPlugin {display:none;} </style>
</head>
<body style="position:relative;"class="page-template page-template-template-one-page page-template-template-one-page-php page page-id-256">





     
        
           

    


<div class="gla_page gla_middle_titles" id="gla_page">

    
    
    <!-- To Top -->
    <a href="#gla_page" class="gla_top ti ti-angle-up gla_go"></a>
    <a href="https://wa.me/918883344064" target="_blank" class="gla_top_w">
    	<img src="images/whatsapp_logo.png" class="whatsapp_logo">
    </a>
        	        
    <!-- Header -->
    <header class="gla_header">       


        
                    <nav class="gla_light_nav gla_other_nav"   >

            
            <div class="container">
                
                <div class="gla_logo_container clearfix">

                                        
                    <div class="gla_logo_txt">

<img src="images/logos.png">
                                                 <!-- Logo -->
                        <a href="index.php" class="gla_logo">A To Infinity Events</a>
                        
                                                <!-- Text Logo -->
                        <div class="gla_logo_und">Wedding Planner</div>
                                               
                        
                        
                    </div>
                </div>
          

            

								
																		<!-- Menu -->
	                <div class="gla_main_menu gla_main_menu_mobile">
	                    
	                    <div class="gla_main_menu_icon">
	                        <i></i><i></i><i></i><i></i>
	                        <b>Menu</b>
	                        <b class="gla_main_menu_icon_b">Back</b>
	                    </div>
	                </div>
	                
	                <!-- Menu Content -->
	                <div class="gla_main_menu_content gla_image_bck" data-color="rgba(0,0,0,0.9)" data-image="">
	                    <!-- Over -->
	                    <div class="gla_over" data-color="#FFF" data-opacity="0.7"></div>
	                </div>

	                <div class="gla_main_menu_content_menu gla_wht_txt text-right">
	                    <div class="container">
	                        <div class="menu-menu-1-container"><ul id="menu-menu-1" class="menu"><li id="menu-item-470" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home  menu-item-470"><a href="index.php" >Home</a>
</li>
<li id="menu-item-769" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-769"><a href="about.php" >About us</a>
</li>
<li id="menu-item-770" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-470"><a href="#" >Services</a>
<ul class="sub-menu">
	<li id="menu-item-774" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-774"><a href="service.php" >Weddings</a></li>
	<li id="menu-item-775" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-775"><a href="service.php" >Graduations</a></li>
	<li id="menu-item-776" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-776"><a href="service.php" >Anniversaries</a></li>
	<li id="menu-item-777" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-777"><a href="service.php" >Birthday Parties</a></li>
</ul>
</li>
<li id="menu-item-798" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-798"><a href="gallery.php" >Gallery</a>
</li>
<li id="menu-item-772" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-772"><a href="testimonial.php" >Testimonial</a></li>
<li id="menu-item-773" class="menu-item menu-item-type-custom menu-item-object-custom  menu-item-has-mega-menu menu-item-773"><a href="contact.php" >Contact us</a></li>
</ul></div>	                        <div class="gla_main_menu_content_menu_copy">
	                        

	                        	                            	                        	                            
	                        </div>
	                    </div>
	                    <!-- container end -->
	                </div>
	                <!-- menu content end -->

	                <!-- Search Block -->
	                <div class="gla_search_block">
	 
	                    	                        	                    
	                </div>
	                <!-- Search Block End -->

	                <!-- Top Menu -->
	                <div class="gla_default_menu">
	                    <div class="menu-menu-1-container"><ul id="menu-menu-2" class="menu"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-470"><a href="index.php" >Home</a>

</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-769"><a href="about.php" >About us</a>

</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-770"><a href="#" >Services</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-774"><a href="service.php" >Wedding</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-775"><a href="service.php" >Graduations</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-776"><a href="service.php" >Anniversaries</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-777"><a href="service.php" >Birthday Parties</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category  menu-item-798"><a href="gallery.php" >Gallery</a>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-772"><a href="testimonial.php" >Testimonial</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom  menu-item-has-mega-menu menu-item-773"><a href="contact.php" >Contact us</a></li>
</ul></div>	                </div>
	                <!-- Top Menu End -->
	                

								



               
            </div>
            <!-- container end -->
        </nav>
        
    </header>
    <!-- Header End -->



<!-- Content -->
<div class="about">
         <div class="container ">
            <div class="row d_flex">
               <div class="col-md-5">
                  <div class="titlepage">
                     <h2>About us</h2>
                     <span>A to Infinity in Helios Event Wedding Brand provides a professional wedding Management service that delivers pro-active, innovative and tailored wedding solutions.<br><br>
                     There was a great feast at the end of the legal formalities of marriage. The tables were filled with delicious food. There were various items of meat, fish, and vegetables. Some of my cousins have sincerely served the guests. The wedding feast was full of laughter and heartfelt conversation. A long time later, on this occasion, I met many relatives and friends.</span>
                  </div>
               </div>
               <div class="col-md-7">
                  
			   <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
     
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
     

      <div class="item active">
        <img src="images/nw1.jpeg" alt="Chicago" style="width:100%;">
      </div>
       <div class="item">
        <img src="images/nw4.jpeg" alt="Los Angeles" style="width:100%;">
      </div>
    
      <div class="item">
        <img src="images/nw9.jpeg" alt="New york" style="width:100%;">
      </div>

      <div class="item">
        <img src="images/nw3.jpeg" alt="New york" style="width:100%;">
      </div>

      
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
  
    
    
  </div>
</div>

               </div>
            </div>
         </div>
      </div> 
<!-- Content End -->

<section   class=" gla_section gla_image_bck    gla_section_sml_padding" style=background-color:#e5e5e5; >
		

		
		
		

		


		    <div class="container ">
    
		
    
		

    





<div class="fw-col-xs-12 fw-col-sm-4   gla_bordered_block gla_grey_border    gla_col"  >
	
	
    
    
    <div class="  ">	
    
		<div class="gla_text_block">
<p>© 2023  All Rights Reserved - Designed By MSK<a href="#"> &#9733;</a></p>
</div>    </div>
    
	
</div>






<div class="fw-col-xs-12 fw-col-sm-4 enh_push_none  gla_bordered_block gla_grey_border  text-center  gla_col"  >
	
	
    
    
    <div class="  ">	
    
		
<!-- Social Buttons -->
<div class="gla_social_btns">
&nbsp;&nbsp;&nbsp;&nbsp;
<a title="" href="https://instagram.com/atoinfinityevents?igshid=ZDdkNTZiNTM=" target="_blank"><i class="fa fa-instagram" style=" background: radial-gradient(circle at 30% 107%, #fdf497 0%, #fdf497 5%, #fd5949 45%, #d6249f 60%, #285AEB 90%);
  -webkit-background-clip: text;
          /* Also define standard property for compatibility */
          background-clip: text;
  -webkit-text-fill-color: transparent; font-size:28px;"></i></a>

&nbsp;&nbsp;&nbsp;
      
<a title="" href="https://www.facebook.com/profile.php?id=100083206935363&mibextid=ZbWKwL"  target="_blank"><i class="fa fa-facebook" style="color:blue; font-size:28px;"></i></a>
      &nbsp;

      <a title="" href="https://www.youtube.com/@atoinfinityevents" target="_blank"><i class="ti fa fa-youtube-play gla_icon_box" style="color:red; font-size:28px;"></i></a>
            
    
</div>  
<a href="https://wa.me/918883344064" target="_blank" class="gla_top_w">
    	<img src="images/whatsapp_logo.png" class="whatsapp_logo" style="float:right;">
    </a> 
 </div>

	
</div>






<div class="fw-col-xs-12 fw-col-sm-4   gla_bordered_block gla_grey_border    gla_col"  >
	
	
    
    
    <div class="  ">	
    
		    </div>
    
	
</div>


    </div>
    <!-- container end -->
</section>
<!-- section end --></div>



</section>
<!-- Content End -->
    

            


    



    </div>
    <!-- Page End -->
<script type='text/javascript' src='wp-includes/js/imagesloaded.min55a0.js?ver=3.2.0'></script>
<script type='text/javascript' src='wp-content/themes/glanztheme/js/glanztheme_library5152.js?ver=1.0'></script>
<script type='text/javascript' src='wp-content/plugins/unyson/framework/static/js/fw-form-helpersfc3c.js?ver=2.4.4'></script>
<script type='text/javascript' src='wp-content/themes/glanztheme/js/navigation4a7d.js?ver=20151215'></script>
<script type='text/javascript' src='wp-content/themes/glanztheme/js/skip-link-focus-fix4a7d.js?ver=20151215'></script>
<script type='text/javascript' src='wp-includes/js/jquery/ui/core.mine899.js?ver=1.11.4'></script>
<script type='text/javascript' src='wp-includes/js/jquery/ui/datepicker.mine899.js?ver=1.11.4'></script>
<script type='text/javascript'>
jQuery(document).ready(function(jQuery){jQuery.datepicker.setDefaults({"closeText":"Close","currentText":"Today","monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Previous","dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"dateFormat":"MM d, yy","firstDay":1,"isRTL":false});});
</script>
<script type='text/javascript' src='wp-content/themes/glanztheme/js/glanztheme_script5152.js?ver=1.0'></script>
<script type='text/javascript' src='wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/core218e.js?ver=5.0.18'></script>
<script type='text/javascript' src='wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/transition218e.js?ver=5.0.18'></script>
<script type='text/javascript' src='wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/background218e.js?ver=5.0.18'></script>
<script type='text/javascript' src='wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/background.init218e.js?ver=5.0.18'></script>
<script type='text/javascript' src='wp-includes/js/wp-embed.min218e.js?ver=5.0.18'></script>


</body>

<!-- Mirrored from glanz.starkethemes.com/wedding-planner/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 03 Jan 2023 06:02:10 GMT -->
</html>
<script>
	$('#myCarousel').carousel({
	interval: 4000
})
</script>
