<!DOCTYPE html>
<html lang="en-US">

<!-- Mirrored from glanz.starkethemes.com/wedding-planner/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 03 Jan 2023 06:01:35 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<!-- /Added by HTTrack -->
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.no-icons.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" rel="stylesheet" />
<link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.min.css" rel="stylesheet">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.0.3/css/font-awesome.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<title>A To Infinity Events</title>
<link rel='dns-prefetch' href='http://fonts.googleapis.com/' />
<link rel='dns-prefetch' href='http://s.w.org/' />
<link rel="alternate" type="application/rss+xml" title="Glanz &raquo; Feed" href="feed/index.html" />
<link rel="alternate" type="application/rss+xml" title="Glanz &raquo; Comments Feed" href="comments/feed/index.html" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/glanz.starkethemes.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.0.18"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])?!1:!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55358,56760,9792,65039],[55358,56760,8203,9792,65039])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}

@media (max-width: 800px) {
 .carousel


}
</style>

<link rel='stylesheet' id='wp-block-library-css'  href='wp-includes/css/dist/block-library/style.min218e.css?ver=5.0.18' type='text/css' media='all' />
<link rel='stylesheet' id='glanztheme-studio-fonts-css'  href='http://fonts.googleapis.com/css?family=Dosis%3A400%2C700%7COpen%2BSans%3A400%2C400i%2C700%2C700i%7CPlayfair+Display%3A400%2C400i%2C700%2C700i&amp;ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='glanztheme-library-css'  href='wp-content/themes/glanztheme/css/glanztheme_library218e.css?ver=5.0.18' type='text/css' media='all' />
<link rel='stylesheet' id='themify-icons-css'  href='wp-content/themes/glanztheme/fonts/themify-icons218e.css?ver=5.0.18' type='text/css' media='all' />
<link rel='stylesheet' id='marsha-font-css'  href='wp-content/themes/glanztheme/fonts/marsha/stylesheet218e.css?ver=5.0.18' type='text/css' media='all' />
<link rel='stylesheet' id='fontawesome-icons-css'  href='wp-content/themes/glanztheme/fonts/font-awesome/css/font-awesome.min218e.css?ver=5.0.18' type='text/css' media='all' />
<link rel='stylesheet' id='glanztheme-main-styles-css'  href='wp-content/themes/glanztheme/css/glanztheme_style218e.css?ver=5.0.18' type='text/css' media='all' />
<link rel='stylesheet' id='glanztheme-style-css'  href='wp-content/themes/glanztheme/style218e.css?ver=5.0.18' type='text/css' media='all' />
<link rel='stylesheet' id='fw-ext-breadcrumbs-add-css-css'  href='wp-content/plugins/unyson/framework/extensions/breadcrumbs/static/css/style218e.css?ver=5.0.18' type='text/css' media='all' />
<link rel='stylesheet' id='fw-ext-builder-frontend-grid-css'  href='wp-content/plugins/unyson/framework/extensions/builder/static/css/frontend-gridd115.css?ver=1.2.12' type='text/css' media='all' />
<link rel='stylesheet' id='fw-ext-forms-default-styles-css'  href='wp-content/plugins/unyson/framework/extensions/forms/static/css/frontendda48.css?ver=2.7.24' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='wp-content/plugins/unyson/framework/static/libs/font-awesome/css/font-awesome.minda48.css?ver=2.7.24' type='text/css' media='all' />
<link rel='stylesheet' id='fw-shortcode-section-background-video-css'  href='wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/css/background218e.css?ver=5.0.18' type='text/css' media='all' />
<link rel='stylesheet' id='fw-shortcode-section-css'  href='wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/css/styles218e.css?ver=5.0.18' type='text/css' media='all' />
<link rel='stylesheet' id='fw-shortcode-divider-css'  href='wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/divider/static/css/styles218e.css?ver=5.0.18' type='text/css' media='all' />
<script type='text/javascript' src='wp-includes/js/jquery/jqueryb8ff.js?ver=1.12.4'></script>
<script type='text/javascript' src='wp-includes/js/jquery/jquery-migrate.min330a.js?ver=1.4.1'></script>
<link rel='https://api.w.org/' href='wp-json/index.html' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="xmlrpc0db0.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.0.18" />
<link rel="canonical" href="index.html" />
<link rel='shortlink' href='index03bd.html?p=256' />
<link rel="alternate" type="application/json+oembed" href="wp-json/oembed/1.0/embed4416.json?url=http%3A%2F%2Fglanz.starkethemes.com%2Fwedding-planner%2F" />
<link rel="alternate" type="text/xml+oembed" href="wp-json/oembed/1.0/embed778d?url=http%3A%2F%2Fglanz.starkethemes.com%2Fwedding-planner%2F&amp;format=xml" />
<style type="text/css">.rsvpArea, .rsvpParagraph, #rsvpPlugin {display:none;} </style>
</head>
<body style="position:relative;"class="page-template page-template-template-one-page page-template-template-one-page-php page page-id-256">





     <!-- whatsapp_logo -->
<!-- 
<div class="whatsapp_logo_outer">
<a href="https://wa.me/918883344064" target="_blank"> <img src="images/whatsapp_logo.png" class="whatsapp_logo" id="gla_top ti ti-angle-up gla_go"></a>
</div> -->
<!-- whatsapp_logo -->
        
           

    


<div class="gla_page gla_middle_titles" id="gla_page">

    
    
    
    <!-- To Top -->
    
    <a href="#gla_page" class="gla_top ti ti-angle-up gla_go"></a>
    <!-- <a href="https://wa.me/918883344064" target="_blank" class="gla_top_w">
    	<img src="images/whatsapp_logo.png" class="whatsapp_logo">
    </a> -->
   
    	        
    <!-- Header -->
    <header class="gla_header">       


        
                    <nav class="gla_light_nav gla_transp_nav  "   >

            
            <div class="container">
                
                <div class="gla_logo_container clearfix">
<img src="images/logos.png">
                                                 <!-- Logo -->
                                        
                    <div class="gla_logo_txt">

                        <a href="index.php" class="gla_logo">
                        A To Infinity Events
                        </a>
                        
                                                <!-- Text Logo -->
                        <div class="gla_logo_und">Wedding Planner</div>
                                               
                        
                        
                    </div>
                </div>
          

            

								
																		<!-- Menu -->
	                <div class="gla_main_menu gla_main_menu_mobile">
	                    
	                    <div class="gla_main_menu_icon">
	                        <i></i><i></i><i></i><i></i>
	                        <b>Menu</b>
	                        <b class="gla_main_menu_icon_b">Back</b>
	                    </div>
	                </div>
	                
	                <!-- Menu Content -->
	                <div class="gla_main_menu_content gla_image_bck" data-color="rgba(0,0,0,0.9)" data-image="">
	                    <!-- Over -->
	                    <div class="gla_over" data-color="white" data-opacity="0.7"></div>
	                </div>

	                <div class="gla_main_menu_content_menu gla_wht_txt text-right">
	                    <div class="container">
	                        <div class="menu-menu-1-container"><ul id="menu-menu-1" class="menu"><li id="menu-item-470" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home  menu-item-470"><a href="index.php" >Home</a>
</li>
<li id="menu-item-769" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-769"><a href="about.php" >About us</a>
</li>
<li id="menu-item-770" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-470"><a href="#" >Services</a>
<ul class="sub-menu">
	<li id="menu-item-774" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-774"><a href="service.php" >Weddings</a></li>
	<li id="menu-item-775" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-775"><a href="service.php" >Graduations</a></li>
	<li id="menu-item-776" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-776"><a href="service.php" >Anniversaries</a></li>
	<li id="menu-item-777" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-777"><a href="service.php" >Birthday Parties</a></li>
</ul>
</li>
<li id="menu-item-798" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-798"><a href="gallery.php" >Gallery</a>
</li>
<li id="menu-item-772" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-772"><a href="testimonial.php" >Testimonial</a></li>
<li id="menu-item-773" class="menu-item menu-item-type-custom menu-item-object-custom  menu-item-has-mega-menu menu-item-773"><a href="contact.php" >Contact us</a></li>
</ul></div>	                        <div class="gla_main_menu_content_menu_copy">
	                        

	                        	                            	                        	                            
	                        </div>
	                    </div>
	                    <!-- container end -->
	                </div>
	                <!-- menu content end -->

	                <!-- Search Block -->
	                <div class="gla_search_block">
	 
	                    	                        	                    
	                </div>
	                <!-- Search Block End -->

	                <!-- Top Menu -->
	                <div class="gla_default_menu">
	                    <div class="menu-menu-1-container"><ul id="menu-menu-2" class="menu"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-470"><a href="index.php" >Home</a>

</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-769"><a href="about.php" >About us</a>

</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-770"><a href="" >Services</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-774"><a href="service.php" >Wedding</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-775"><a href="service.php" >Graduations</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-776"><a href="service.php" >Anniversaries</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-777"><a href="service.php" >Birthday Parties</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category  menu-item-798"><a href="gallery.php" >Gallery</a>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-772"><a href="testimonial.php" >Testimonial</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom  menu-item-has-mega-menu menu-item-773"><a href="contact.php" >Contact us</a></li>
</ul></div>	                </div>
	                <!-- Top Menu End -->
	                

								



               
            </div>
            <!-- container end -->
        </nav>
        
    </header>
    <!-- Header End -->
        <!-- Slider -->
        <section class="gla_slider gla_image_bck  gla_wht_txt" data-stellar-background-ratio="" data-image="" data-color="">
            
                        <!-- Over -->

     <!-- <div class="col-md-12"> -->
                  
			   <div id="myCarousel" class="carousel slide gla_over" data-ride="carousel" >
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
     

      <div class="item active">
        <img src="images/nw1.jpeg"  class="carousel_imgs" style="width:100%; background-size: cover;">
      </div>
       <div class="item">
        <img src="images/nw4.jpeg" class="carousel_imgs"  style="width:100%;">
      </div>
    
      <div class="item">
        <img src="images/nw9.jpeg" class="carousel_imgs" style="width:100%;">
      </div>

      <div class="item">
        <img src="images/nw3.jpeg" class="carousel_imgs"  style="width:100%;">
      </div>
      
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
  
    
    
  </div>

          <!--   <div class="gla_over" data-gradient="" style="background-image: url('images/banner.jpg'); background-repeat: no-repeat; background-size: cover; " data-opacity=""></div> -->
            
            <!-- <div class="gla_over" data-gradient="" style="background-image: url('images/w2.jpg'); background-repeat: no-repeat; background-size: cover; -webkit-filter: blur(9px); filter: blur(9px);" data-opacity="0.8"></div> -->

            <div class="container">





                <!-- Slider Texts -->
                <div class="gla_slide_txt gla_slide_center_middle text-center" >


                		
                                        
      
                    
                                        
                    
                    
                    
                
                </div>
                <!-- Slider Texts End -->
            
            </div>
            <!-- container end -->

            <!-- Slide Down -->
           


        </section>
        <!-- Slider End -->
    <!-- Content -->

    <section id="gla_content" class="gla_content">



		
<div class="fw-page-builder-content">

<!-- section -->
<section   class=" gla_section gla_image_bck    " style=background-color:#f5efe4; >
		

		
		
		

		


		    <div class="container text-center">
    
		
    				<!-- Title -->
				<h3 class="" style="font-family:Verdana,Geneva, sans-serif;"><b>Find Your Best<br> Wedding Stage Decorations</b></h3><br>
		
						<!-- Subtitle -->
                        <br>
                        
				<h3 class="gla_subtitle">If you think We will do</h3>
		


    </div>
    <!-- container end -->
</section>
<!-- section end -->


<!-- section -->
<section   class=" gla_section gla_image_bck    " style=background-color:#d8e5e9; >
		

		
		
		

		


		    <div class="container text-center">
    
		
    				<!-- Title -->
				<h3 class="gla_h2_title" style="font-family:Verdana,Geneva, sans-serif;"><b>A to Infinity Events Decorations</b></h3>
		
		

    <div class="gla_text_block">
<p>A to Infinity in Helios Event Wedding Brand provides a professional wedding Management service that delivers pro-active, innovative and tailored wedding solutions</p></div>

<!-- boxes -->
<div class="gla_icon_boxes row text-left">

	
		<!-- item -->
									<div class="col-md-3 col-sm-6">
		    
    		    			<a href="#" class="gla_news_block">
	            <span class="gla_news_img">
				<span class="gla_over" data-image="images/nw9.jpeg"></span> 
										                   
	            </span>
	           
							<span class="gla_news_cont">
		            <span class="gla_news_title"></span>
		            <p>Wedding Events</p>	            </span>
	        </a>
    		        
    </div> 

  
		<!-- item -->
									<div class="col-md-3 col-sm-6">
		    
    		    			<a href="#" class="gla_news_block">
	            <span class="gla_news_img">
			<span class="gla_over" data-image="images/b1.jpg"></span> 
										                   
	            </span>
	           
							<span class="gla_news_cont">
		            <span class="gla_news_title"></span>
		            <p>Birthday Parties</p>	            </span>
	        </a>
    		        
    </div> 

  
		<!-- item -->
									<div class="col-md-3 col-sm-6">
		    
    		    			<a href="#" class="gla_news_block">
	            <span class="gla_news_img">
					<span class="gla_over" data-image="images/m1.jpg"></span> 
										                   
	            </span>
	           
							<span class="gla_news_cont">
		            <span class="gla_news_title"></span>
		            <p>Bridal Makeup</p>	            </span>
	        </a>
    		        
    </div> 

  
		<!-- item -->
									<div class="col-md-3 col-sm-6">
		    
    		    			<a href="#" class="gla_news_block">
	            <span class="gla_news_img">

						<span class="gla_over" data-image="images/nw3.jpeg"></span> 
										                   
	            </span>
	           
							<span class="gla_news_cont">
		            <span class="gla_news_title"></span>
		            <p>Venue Decoration</p>	            </span>
	        </a>
    		        
    </div> 

  
    


</div>
<!-- boxes end -->

	<!-- <div class="fw-divider-space" style="padding-top: 20px;"></div>

  
                	<a href="#" class="btn"><span>Venues</span></a>
     -->    


    </div>
    <!-- container end -->
</section>
<!-- section end -->

<!-- section -->
<section   class=" gla_section gla_image_bck    "  >
		

		
		
		

		


		    <div class="container text-center">
    
		
    				<!-- Title -->
				<h2 class="gla_h2_title">A to Infinity Events</h2>
		
						<!-- Subtitle -->
                        <br>
                        <br>
                        <br>
				<h3 class="gla_subtitle">All Under one Roof</h3>
		

    
<!-- boxes -->
<div class="gla_icon_boxes row text-left">

    
                
        <!-- item -->
        <div class="col-md-4 col-sm-6">
            <a href="#" class="gla_news_block">
                <span class="gla_news_img">
                               <span class="gla_over" data-image="images/m1.jpg"></span>  
                </span>
               
                <span class="gla_news_cont">
                    <span class="gla_news_title">Best Bridal Makeup</span>
                    <!-- <span class="gla_news_author">07/03/2017</span> -->
                    <p>There are plenty of things to prepare for your special day.<br> But the perfect wedding makeup should definitely be at the top of the list. You want to look flawless in your wedding day</p>
                </span>
            </a>
        </div> 
        
            
                
        <!-- item -->
        <div class="col-md-4 col-sm-6">
            <a href="#" class="gla_news_block">
                <span class="gla_news_img">
                            <span class="gla_over" data-image="images/b1.jpg"></span>  
                </span>
               
                <span class="gla_news_cont">
                    <span class="gla_news_title">Birthday Party</span>
                    <!-- <span class="gla_news_author">07/03/2017</span> -->
                    <p>Birthdays are the most special day of the year for children.<br> It is a day full of celebrations where children enjoy many fun activities, party with their friends and family, receive a lot of gifts and of course…</p>
                </span>
            </a>
        </div> 
        
            
                
        <!-- item -->
        <div class="col-md-4 col-sm-6">
            <a href="#" class="gla_news_block">
                <span class="gla_news_img">
                                   <span class="gla_over" data-image="images/nw8.jpeg"></span>  
                </span>
               
                <span class="gla_news_cont ps-5">
                    <span class="gla_news_title">Best Wedding Decorators</span>
                    <!-- <span class="gla_news_author">07/03/2017</span> -->
                    <p>A wedding ceremony is a joyous occasion through which a couple of men and women start their married life.<br> It is not merely an obligation, but also socially and culturally an important event.</p>
                </span>
            </a>
        </div> 
        
          
        
        
</div>
<!-- boxes end -->



    </div>
    <!-- container end -->
</section>
<!-- section end -->

<!-- section -->
<section   class=" gla_section gla_image_bck    "  >
		

		
		
		

		


		    <div class="container text-center">
    
		
    				<!-- Title -->
				<h2 class="gla_h2_title">What is our Customer's says</h2>
		
		

    



<div class="gla_team_slider_single">
	  
    <div class="gla_reviews_item">
	    <p>There are plenty of things to prepare for your special day.<br> But the perfect wedding makeup should definitely be at the top of the list. You want to look flawless in your wedding day</p>
	    <div class="gla_reviews_item_img">
	        <img src="images/m2.jpg" alt="">
	    </div>
	    <p>Bridal makeup</p>
    </div>

    
    <div class="gla_reviews_item">
	    <p>A wedding ceremony is a joyous occasion through which a couple of men and women start their married life.<br> It is not merely an obligation, but also socially and culturally an important event.</p>
	    <div class="gla_reviews_item_img">
	        <img src="images/nw4.jpeg" alt="">
	    </div>
	    <p>Wedding Hall</p>
    </div>

    
    <div class="gla_reviews_item">
	    <p>Birthdays are the most special day of the year for children.<br> It is a day full of celebrations where children enjoy many fun activities, party with their friends and family, receive a lot of gifts and of course…</p>
	    <div class="gla_reviews_item_img">
	        <img src="images/b1.jpg" alt="">
	    </div>
	    <p>Birthday Events</p>
    </div>

      

</div>

    </div>
    <!-- container end -->
</section>
<!-- section end -->
<!-- section -->
<section   class=" gla_section gla_image_bck    gla_section_sml_padding"  >
		

		
		
		

		


		    <div class="container text-center">
    
		
    
		

    

<!-- icon boxes -->
<div class="gla_icon_boxes gla_partners row" style="padding-left:30px;">
    
     

    <!-- item -->
    <div class="gla_partner_box">
        <a href="#"><img src="images/nw7.jpeg" height="80"></a>
    </div>

     

    <!-- item -->
    <div class="gla_partner_box">
        <a href="#"><img src="images/nw3.jpeg" alt="Amazon" class="gla_partner_img" height="80"></a>
    </div>

    

    <!-- item -->
    <div class="gla_partner_box">
        <a href="#"><img src="images/nw7.jpeg" alt="Bed&amp;Bath" class="gla_partner_img" height="80"></a>
    </div>

     

    <!-- item -->
    <div class="gla_partner_box">
        <a href="#"><img src="images/nw8.jpeg" alt="Crate" class="gla_partner_img" height="80"></a>
    </div>

     

    <!-- item -->
    <div class="gla_partner_box">
        <a href="#"><img src="images/nw9.jpeg" alt="Newlywish" class="gla_partner_img" height="80"></a>
    </div>

     

    <!-- item -->
    <div class="gla_partner_box">
        <a href="#"><img src="images/nw4.jpeg" alt="Dalani" class="gla_partner_img" height="80"></a>
    </div>

    <div class="gla_partner_box">
        <a href="#"><img src="images/nw7.jpeg" alt="Dalani" class="gla_partner_img" height="80"></a>
    </div>

    <div class="gla_partner_box">
        <a href="#"><img src="images/nw4.jpeg" alt="Dalani" class="gla_partner_img" height="80"></a>
    </div>

    <div class="gla_partner_box">
        <a href="#"><img src="images/nw3.jpeg" alt="Dalani" class="gla_partner_img" height="80"></a>
    </div>

    
</div>
<!-- icon boxes end -->

    </div>
    <!-- container end -->
</section>
<!-- section end -->

<!-- section -->
<section   class=" gla_section gla_image_bck    gla_section_sml_padding" style=background-color:#e5e5e5; >
		

		
		
		

		


		    <div class="container ">
    
		
    
		

    





<div class="fw-col-xs-12 fw-col-sm-4   gla_bordered_block gla_grey_border    gla_col"  >
	
	
    
    
    <div class="  ">	
    
		<div class="gla_text_block">
<p>© 2023  All Rights Reserved - Designed By MSK<a href="#"> &#9733;</a></p>
</div>    </div>
    
	
</div>






<div class="fw-col-xs-12 fw-col-sm-4 enh_push_none  gla_bordered_block gla_grey_border  text-center  gla_col"  >
	
	
    
    
    <div class="  ">	
    
		
<!-- Social Buttons -->
<div class="gla_social_btns">
&nbsp;&nbsp;&nbsp;&nbsp;
<a title="" href="https://instagram.com/atoinfinityevents?igshid=ZDdkNTZiNTM=" target="_blank">
	<i class="fa fa-instagram" style=" background: radial-gradient(circle at 30% 107%, #fdf497 0%, #fdf497 5%, #fd5949 45%, #d6249f 60%, #285AEB 90%);
  -webkit-background-clip: text;
          /* Also define standard property for compatibility */
          background-clip: text;
  -webkit-text-fill-color: transparent; font-size:28px;"></i>
</a>

&nbsp;&nbsp;&nbsp;
      
      <a title="" href="https://www.facebook.com/profile.php?id=100083206935363&mibextid=ZbWKwL"  target="_blank"><i class="fa fa-facebook" style="color:blue; font-size:28px;"></i></a>
      &nbsp;
      
      <a title="" href="https://www.youtube.com/@atoinfinityevents" target="_blank"><i class="ti fa fa-youtube-play gla_icon_box" style="color:red; font-size:28px;"></i></a>
            
      <div >
     
</div>
  

 </div>
	

    
</div>
<a href="https://wa.me/918883344064" target="_blank" class="gla_top_w" >
    	<img src="images/whatsapp_logo.png" class="whatsapp_logo" style="float:right;">
    </a>






<div class="fw-col-xs-12 fw-col-sm-4   gla_bordered_block gla_grey_border    gla_col"  >
	
	
    
    
    <div class="  ">	
    
		    </div>
    
	
</div>


    </div>
    <!-- container end -->
</section>
<!-- section end --></div>



</section>
<!-- Content End -->
    

            


    



</div> 
    <!-- Page End -->
<script type='text/javascript' src='wp-includes/js/imagesloaded.min55a0.js?ver=3.2.0'></script>
<script type='text/javascript' src='wp-content/themes/glanztheme/js/glanztheme_library5152.js?ver=1.0'></script>
<script type='text/javascript' src='wp-content/plugins/unyson/framework/static/js/fw-form-helpersfc3c.js?ver=2.4.4'></script>
<script type='text/javascript' src='wp-content/themes/glanztheme/js/navigation4a7d.js?ver=20151215'></script>
<script type='text/javascript' src='wp-content/themes/glanztheme/js/skip-link-focus-fix4a7d.js?ver=20151215'></script>
<script type='text/javascript' src='wp-includes/js/jquery/ui/core.mine899.js?ver=1.11.4'></script>
<script type='text/javascript' src='wp-includes/js/jquery/ui/datepicker.mine899.js?ver=1.11.4'></script>
<script type='text/javascript'>
jQuery(document).ready(function(jQuery){jQuery.datepicker.setDefaults({"closeText":"Close","currentText":"Today","monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Previous","dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"dateFormat":"MM d, yy","firstDay":1,"isRTL":false});});
</script>
<script type='text/javascript' src='wp-content/themes/glanztheme/js/glanztheme_script5152.js?ver=1.0'></script>
<script type='text/javascript' src='wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/core218e.js?ver=5.0.18'></script>
<script type='text/javascript' src='wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/transition218e.js?ver=5.0.18'></script>
<script type='text/javascript' src='wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/background218e.js?ver=5.0.18'></script>
<script type='text/javascript' src='wp-content/plugins/unyson/framework/extensions/shortcodes/shortcodes/section/static/js/background.init218e.js?ver=5.0.18'></script>
<script type='text/javascript' src='wp-includes/js/wp-embed.min218e.js?ver=5.0.18'></script>








</body>

<!-- Mirrored from glanz.starkethemes.com/wedding-planner/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 03 Jan 2023 06:02:10 GMT -->
</html>
